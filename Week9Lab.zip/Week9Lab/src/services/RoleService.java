package services;

import models.Role;
import repo.RoleRepository;

import java.util.List;

public class RoleService {

    private RoleRepository roleRepository = new RoleRepository();

    public Role getById(int id) {
        return roleRepository.findById(id);
    }

    public List<Role> getAll() {
        return roleRepository.findAll();
    }

    public void saveOrUpdate(Role role) {
        roleRepository.save(role);
    }

    public void delete(Role role) {
        roleRepository.delete(role);
    }
}

