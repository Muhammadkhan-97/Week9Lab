package services;

import models.User;
import repo.UserRepository;

import java.util.List;

public class UserService {

    private UserRepository userRepository = new UserRepository();

    public User getByEmail(String email) {
        return userRepository.getById(email);
    }

    public List<User> getAll() {
        return userRepository.getAll();
    }

    public void save(User user) {
        userRepository.save(user);
    }

    public void delete(User user) {
        userRepository.delete(user);
    }

    public void update(User user) {
        userRepository.update(user);
    }
}

