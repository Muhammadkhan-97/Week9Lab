package dataaccess;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import services.RoleService;
import services.UserService;

public class HibernateUtil {

    private static final SessionFactory sessionFactory = buildSessionFactory();

    public static SessionFactory buildSessionFactory() {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
            return new Configuration()
                    .configure()
                    .buildSessionFactory();
        } catch (Exception ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed ->>>>>>>> \n" + ex);
            ex.printStackTrace();
            throw new ExceptionInInitializerError(ex);
        }
    }

    public synchronized static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        // Close caches and connection pools
        getSessionFactory().close();
    }

    public static void main(String[] args) {
        UserService userService = new UserService();
        RoleService roleService = new RoleService();

        System.out.println(userService.getAll());
        System.out.println(roleService.getAll());
    }
}