package servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.Role;
import models.User;
import services.RoleService;
import services.UserService;

/**
 * Servlet implementation class TestServLet
 */
@WebServlet("/user")
public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

//    private RoleService roleService;
    private UserService userService;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
//			userdb = new UserDB(dataSource);
//			roledb = new RoleDB(dataSource);

//            roleService = new RoleService();
            userService = new UserService();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");

        try {
            // read the command parameter
            String thecommad = request.getParameter("command");

            // if command is missing, then default to listening user
            if (thecommad == null) {
                thecommad = "LIST";
            }

            // route the appropriate method
            switch (thecommad) {

                case "LIST":
                    listUser(request, response);
                    break;

                case "ADD":
                    addUser(request, response);
                    break;

                case "LOAD":
                    loadUser(request, response);
                    break;

                case "UPDATE":
                    updateUser(request, response);
                    break;

                case "DELETE":
                    deleteUser(request, response);
                    break;

                default:
                    listUser(request, response);
            }

        } catch (Exception ex) {
            System.out.println("Error initializing database: " + ex.getMessage());
            throw new ServletException(ex);
        }
    }

    private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

        // read user by email form from data
        String email = request.getParameter("email");

        // delete user from data base
        userService.delete(userService.getByEmail(email));

        // sent them back to list student
        listUser(request, response);

    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

        // read user info form from data
        Role realroll = new Role();
        String email = request.getParameter("email");
        String firstName = request.getParameter("firstname");
        String lastName = request.getParameter("lastname");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        if (role.equals("admin")) {
            realroll.setRoleId(1);
            realroll.setRoleName("system admin");
        } else if (role.equals("user")) {
            realroll.setRoleId(2);
            realroll.setRoleName("regular user");
        }

        // create a new user
        User updatedUser = new User(email, firstName, lastName, password, realroll);

        // perform update on database
        userService.update(updatedUser);

        // sent them back to list user
        listUser(request, response);

    }

    private void loadUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

        // read user email from form data
        String email = request.getParameter("email");

        // get user from database
        User user = userService.getByEmail(email);

        // place the student in the request attribute
        request.setAttribute("THE_USER", user);

        listUser(request, response);
    }

    private void addUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

        // read the user info form from data
        Role realroll = new Role();
        String email = request.getParameter("email");
        String firstName = request.getParameter("firstname");
        String lastName = request.getParameter("lastname");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        if (role.equals("1")) {
            realroll.setRoleId(1);
            realroll.setRoleName("system admin");
        } else if (role.equals("2")) {
            realroll.setRoleId(2);
            realroll.setRoleName("regular user");
        }

        // create a new user objects
        User newUser = new User(email, firstName, lastName, password, realroll);

        // Add the user to the database
        userService.save(newUser);

        // sent back to the user list
        listUser(request, response);
    }

    /*
     * private void listRole(HttpServletRequest request, HttpServletResponse
     * response) throws Exception { // get roles from RoleDB List<Role> roles =
     * roledb.getRoles();
     *
     * // add roles to the request request.setAttribute("ROLE_LIST", roles);
     *
     * // forward to JSP page view RequestDispatcher dispatcher =
     * request.getRequestDispatcher("/users.jsp"); dispatcher.forward(request,
     * response);
     *
     * }
     */
    private void listUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

        // get user from UserDB
        List<User> user = userService.getAll();

        // add student to the request
        request.setAttribute("USER_LIST", user);

        // sent to JSP page view
        RequestDispatcher dispatcher = request.getRequestDispatcher("/users.jsp");
        dispatcher.forward(request, response);
    }

}